function setup() {
  createCanvas(1500, 2250);
}

function draw() {
  background("#003366");
}
function setup() {
  createCanvas(1500, 2250);
  img = loadImage('https://media.discordapp.net/attachments/595047755869847570/1189089572613783552/f2.gif?ex=659ce4f6&is=658a6ff6&hm=a7def3d31a2d6f6e8506675281d6d6b2712dd3362e753eef308e1e354d72a7ce&=&width=441&height=662'); // Load the image
}

function draw() {
image(img, 0, 0);
}
